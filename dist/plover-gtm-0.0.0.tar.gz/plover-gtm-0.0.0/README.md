# plover-no-gui-dict-manager
Lookup and Add Dictionary entries without the GUI. Lookup/Add last fingerspelled word in-line.
